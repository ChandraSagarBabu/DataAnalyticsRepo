﻿using ConnectionTesting.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace ConnectionTesting.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SchoolController : ControllerBase
    {

        private readonly SchoolRepository schoolRepository;

        public SchoolController(SchoolRepository schoolRepository)
        {
            this.schoolRepository = schoolRepository;
        }

        [HttpGet("Getallschools")]
        public IActionResult getSchools()
        {
            try
            {
                return Ok(schoolRepository.GetSchoolList());
            }
            catch (Exception ex)
            {

                using StreamWriter writer = new StreamWriter("C:\\SagarBabu\\Error Log\\err.txt", true);
                writer.Write("--------------------------------------------------------------------------------------------------------------------------- \n" +
                                    DateTime.Now.ToString()
                                    + "\n" +
                                    ex.Message + ex.InnerException == null ? " " : ex.InnerException.ToString() +
                                    "\n------------------------------------------------------------------------------------------------------------------------\n");
                writer.Close();
                return StatusCode(402, "Some error has occured");
            }
        }


    }
}
