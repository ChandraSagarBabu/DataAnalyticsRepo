﻿using ConnectionTesting.Models;
using ConnectionTesting.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ConnectionTesting.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly StudentRepository studentRepository;


        public StudentController(StudentRepository studentRepository)
        {
            this.studentRepository = studentRepository;
        }

        [HttpGet("GetstudentlistbyPgNo/{pg_no}")]
        public IActionResult GetStudentListByPageNo(short pg_no)
        {
            try
            {
                List<StudentList> studentList = studentRepository.GetStudentLists(pg_no);

                if(studentList.Count > 0)
                {
                    return Ok(studentList);
                }
                else
                {
                    return StatusCode(500,"Enter a valid page number");
                }

            }
            catch (Exception ex)
            {

                using StreamWriter writer = new StreamWriter("C:\\SagarBabu\\Error Log\\err.txt", true);
                writer.Write("--------------------------------------------------------------------------------------------------------------------------- \n" +
                                    DateTime.Now.ToString()
                                    + "\n" +
                                    ex.Message + ex.InnerException == null ? " " : ex.InnerException.ToString() +
                           "\n------------------------------------------------------------------------------------------------------------------------\n");
                writer.Close();
                return StatusCode(402, "Some error has occured");
            }
        }

        [HttpPut(("UpdateStudentDetails"))]

        public IActionResult UpdateStudentDetails(StudentUpdate studentUpdate)
        {
                try
                {
                    studentRepository.UpdateStudent(studentUpdate);
                    return Ok();
                }
                catch (Exception ex)
                {
                    using StreamWriter writer = new StreamWriter("C:\\SagarBabu\\Error Log\\err.txt", true);
                    writer.Write("--------------------------------------------------------------------------------------------------------------------------- \n" +
                                        DateTime.Now.ToString()
                                        + "\n" +
                                        ex.Message + ex.InnerException == null ? " " : ex.InnerException.ToString() +
                               "\n------------------------------------------------------------------------------------------------------------------------\n");
                    writer.Close();
                    return StatusCode(402, "Some error has occured");

                }
        }
    }
}
