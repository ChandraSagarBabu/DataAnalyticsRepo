﻿using System;
using System.Collections.Generic;

namespace ConnectionTesting.Models;

public partial class School
{
    public short SchoolId { get; set; }

    public short? CustomerId { get; set; }

    public string? SchoolName { get; set; }

    public virtual Customer? Customer { get; set; }

    public virtual ICollection<Student> Students { get; set; } = new List<Student>();
}
