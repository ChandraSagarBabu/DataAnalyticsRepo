﻿using System;
using System.Collections.Generic;

namespace ConnectionTesting.Models;

public partial class Valuation
{
    public long ValuationId { get; set; }

    public long? AssessmentSessionId { get; set; }

    public string? ValuationStatus { get; set; }

    public short? Score { get; set; }

    public virtual AssessmentSession? AssessmentSession { get; set; }
}
