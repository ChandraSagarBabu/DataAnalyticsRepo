﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ConnectionTesting.Models;

public partial class StudentUpdate
{
    [Required (ErrorMessage = "Student ID was not provided.")]
    public short StudentId { get; set; }

    public string? StudentName { get; set; }

    public short? StudentAge { get; set; }

    public string? StudentGender { get; set; }

}
