﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ConnectionTesting.Models;

public partial class PostgresContext : DbContext
{

    private readonly IConfiguration configuration;
    public PostgresContext() { }
    public PostgresContext( IConfiguration configuration)
    {
        this.configuration = configuration;
    }

    public virtual DbSet<Assessment> Assessments { get; set; }

    public virtual DbSet<AssessmentSession> AssessmentSessions { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Grade> Grades { get; set; }

    public virtual DbSet<School> Schools { get; set; }

    public virtual DbSet<SchoolList> SchoolLists { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    public virtual DbSet<StudentList> StudentLists { get; set; }

    public virtual DbSet<Subject> Subjects { get; set; }

    public virtual DbSet<Test> Tests { get; set; }

    public virtual DbSet<Valuation> Valuations { get; set; }

    public virtual List<StudentList> GetStudentLists(short pageNo)
    {
        return StudentLists.FromSqlRaw($"select * from sp_get_students_list(P_PAGENUM=>({pageNo}::smallint));").ToList();
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseNpgsql(configuration.GetConnectionString("myConnection"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasPostgresExtension("pg_catalog", "adminpack");

        modelBuilder.Entity<Assessment>(entity =>
        {
            entity.HasKey(e => e.AssessmentId).HasName("assessment_pkey");

            entity.ToTable("assessment");

            entity.Property(e => e.AssessmentId)
                .UseIdentityAlwaysColumn()
                .HasColumnName("assessment_id");
            entity.Property(e => e.AssessmentName)
                .HasMaxLength(100)
                .HasColumnName("assessment_name");
            entity.Property(e => e.SubjectId).HasColumnName("subject_id");

            entity.HasOne(d => d.Subject).WithMany(p => p.Assessments)
                .HasForeignKey(d => d.SubjectId)
                .HasConstraintName("assessment_subject_id_fkey");
        });

        modelBuilder.Entity<AssessmentSession>(entity =>
        {
            entity.HasKey(e => e.AssessmentSessionId).HasName("assessment_sessions_pkey");

            entity.ToTable("assessment_sessions");

            entity.Property(e => e.AssessmentSessionId)
                .UseIdentityAlwaysColumn()
                .HasColumnName("assessment_session_id");
            entity.Property(e => e.AssessmentId).HasColumnName("assessment_id");
            entity.Property(e => e.EndDatetime)
                .HasPrecision(4)
                .HasColumnName("end_datetime");
            entity.Property(e => e.MaxMarks).HasColumnName("max_marks");
            entity.Property(e => e.SessionStatus)
                .HasMaxLength(50)
                .HasColumnName("session_status");
            entity.Property(e => e.StartDatetime)
                .HasPrecision(4)
                .HasColumnName("start_datetime");
            entity.Property(e => e.StudentId).HasColumnName("student_id");

            entity.HasOne(d => d.Assessment).WithMany(p => p.AssessmentSessions)
                .HasForeignKey(d => d.AssessmentId)
                .HasConstraintName("assessment_sessions_assessment_id_fkey");

            entity.HasOne(d => d.Student).WithMany(p => p.AssessmentSessions)
                .HasForeignKey(d => d.StudentId)
                .HasConstraintName("assessment_sessions_student_id_fkey");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("customer_pkey");

            entity.ToTable("customer");

            entity.Property(e => e.CustomerId)
                .UseIdentityAlwaysColumn()
                .HasColumnName("customer_id");
            entity.Property(e => e.CustomerName)
                .HasMaxLength(100)
                .HasColumnName("customer_name");
        });

        modelBuilder.Entity<Grade>(entity =>
        {
            entity.HasKey(e => e.GradeId).HasName("grades_pkey");

            entity.ToTable("grades");

            entity.Property(e => e.GradeId)
                .UseIdentityAlwaysColumn()
                .HasColumnName("grade_id");
            entity.Property(e => e.GradeCode)
                .HasMaxLength(2)
                .HasColumnName("grade_code");
            entity.Property(e => e.MaxScore).HasColumnName("max_score");
            entity.Property(e => e.MinScore).HasColumnName("min_score");
            entity.Property(e => e.SubjectId).HasColumnName("subject_id");

            entity.HasOne(d => d.Subject).WithMany(p => p.Grades)
                .HasForeignKey(d => d.SubjectId)
                .HasConstraintName("grades_subject_id_fkey");
        });

        modelBuilder.Entity<School>(entity =>
        {
            entity.HasKey(e => e.SchoolId).HasName("schools_pkey");

            entity.ToTable("schools");

            entity.Property(e => e.SchoolId)
                .UseIdentityAlwaysColumn()
                .HasColumnName("school_id");
            entity.Property(e => e.CustomerId).HasColumnName("customer_id");
            entity.Property(e => e.SchoolName)
                .HasMaxLength(100)
                .HasColumnName("school_name");

            entity.HasOne(d => d.Customer).WithMany(p => p.Schools)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("schools_customer_id_fkey");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.StudentId).HasName("students_pkey");

            entity.ToTable("students");

            entity.Property(e => e.StudentId)
                .UseIdentityAlwaysColumn()
                .HasColumnName("student_id");
            entity.Property(e => e.SchoolId).HasColumnName("school_id");
            entity.Property(e => e.StudentAge).HasColumnName("student_age");
            entity.Property(e => e.StudentGender)
                .HasMaxLength(1)
                .HasColumnName("student_gender");
            entity.Property(e => e.StudentName)
                .HasMaxLength(100)
                .HasColumnName("student_name");

            entity.HasOne(d => d.School).WithMany(p => p.Students)
                .HasForeignKey(d => d.SchoolId)
                .HasConstraintName("students_school_id_fkey");
        });

        modelBuilder.Entity<Subject>(entity =>
        {
            entity.HasKey(e => e.SubjectId).HasName("subject_pkey");

            entity.ToTable("subject");

            entity.Property(e => e.SubjectId)
                .UseIdentityAlwaysColumn()
                .HasColumnName("subject_id");
            entity.Property(e => e.SubjectName)
                .HasMaxLength(100)
                .HasColumnName("subject_name");
        });

        modelBuilder.Entity<Test>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Test", tb => tb.HasComment("first postgre table\n"));

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .UseIdentityAlwaysColumn()
                .HasColumnName("ID");
        });

        modelBuilder.Entity<Valuation>(entity =>
        {
            entity.HasKey(e => e.ValuationId).HasName("valuation_pkey");

            entity.ToTable("valuation");

            entity.Property(e => e.ValuationId)
                .UseIdentityAlwaysColumn()
                .HasColumnName("valuation_id");
            entity.Property(e => e.AssessmentSessionId).HasColumnName("assessment_session_id");
            entity.Property(e => e.Score)
                .HasDefaultValue((short)0)
                .HasColumnName("score");
            entity.Property(e => e.ValuationStatus)
                .HasMaxLength(10)
                .HasColumnName("valuation_status");

            entity.HasOne(d => d.AssessmentSession).WithMany(p => p.Valuations)
                .HasForeignKey(d => d.AssessmentSessionId)
                .HasConstraintName("valuation_assessment_session_id_fkey");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
