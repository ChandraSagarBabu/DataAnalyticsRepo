﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ConnectionTesting.Models;

public partial class SchoolList
{
    [Key]
    public short school_id { get; set; }

    public string? custome_name { get; set; }

    public string? school_name { get; set; }
}
