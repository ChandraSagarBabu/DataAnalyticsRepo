﻿using System;
using System.Collections.Generic;

namespace ConnectionTesting.Models;

public partial class Assessment
{
    public long AssessmentId { get; set; }

    public string? AssessmentName { get; set; }

    public short? SubjectId { get; set; }

    public virtual ICollection<AssessmentSession> AssessmentSessions { get; set; } = new List<AssessmentSession>();

    public virtual Subject? Subject { get; set; }
}
