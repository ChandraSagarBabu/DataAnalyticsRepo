﻿using System;
using System.Collections.Generic;

namespace ConnectionTesting.Models;

/// <summary>
/// first postgre table
/// 
/// </summary>
public partial class Test
{
    public long Id { get; set; }
}
