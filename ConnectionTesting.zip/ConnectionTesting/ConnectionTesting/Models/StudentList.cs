﻿using System.ComponentModel.DataAnnotations;

namespace ConnectionTesting.Models
{
    public class StudentList
    {
        [Key]
        public short student_id { get; set; }

        public string? student_name { get; set; }

        public short? student_age { get; set; }

        public char? student_gender { get; set; }

        public string? school_name { get; set; }

    }
}
