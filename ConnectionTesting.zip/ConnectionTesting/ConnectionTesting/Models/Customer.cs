﻿using System;
using System.Collections.Generic;

namespace ConnectionTesting.Models;

public partial class Customer
{
    public short CustomerId { get; set; }

    public string? CustomerName { get; set; }

    public virtual ICollection<School> Schools { get; set; } = new List<School>();
}
