﻿using System;
using System.Collections.Generic;

namespace ConnectionTesting.Models;

public partial class Grade
{
    public short GradeId { get; set; }

    public short? SubjectId { get; set; }

    public string? GradeCode { get; set; }

    public short? MinScore { get; set; }

    public short? MaxScore { get; set; }

    public virtual Subject? Subject { get; set; }
}
