﻿using System;
using System.Collections.Generic;

namespace ConnectionTesting.Models;

public partial class Student
{
    public short StudentId { get; set; }

    public short? SchoolId { get; set; }

    public string? StudentName { get; set; }

    public short? StudentAge { get; set; }

    public char? StudentGender { get; set; }

    public virtual ICollection<AssessmentSession> AssessmentSessions { get; set; } = new List<AssessmentSession>();

    public virtual School? School { get; set; }
}
