﻿using System;
using System.Collections.Generic;

namespace ConnectionTesting.Models;

public partial class AssessmentSession
{
    public long AssessmentSessionId { get; set; }

    public long? AssessmentId { get; set; }

    public short? StudentId { get; set; }

    public string? SessionStatus { get; set; }

    public DateTime? StartDatetime { get; set; }

    public DateTime? EndDatetime { get; set; }

    public short? MaxMarks { get; set; }

    public virtual Assessment? Assessment { get; set; }

    public virtual Student? Student { get; set; }

    public virtual ICollection<Valuation> Valuations { get; set; } = new List<Valuation>();
}
