﻿using ConnectionTesting.Models;
using Microsoft.EntityFrameworkCore;

namespace ConnectionTesting.Repositories
{
    public class SchoolRepository:ISchoolRepository
    {
        private readonly PostgresContext mycontext;


        public SchoolRepository(PostgresContext mycontext)
        {
            this.mycontext = mycontext;

        }

        public List<SchoolList> GetSchoolList()
        {
            return mycontext.SchoolLists.FromSqlRaw("select * from sp_get_school_list();").ToList();
        }
    }
}
