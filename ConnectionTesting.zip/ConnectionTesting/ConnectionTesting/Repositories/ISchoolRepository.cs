﻿using ConnectionTesting.Models;

namespace ConnectionTesting.Repositories
{
    public interface ISchoolRepository
    {
        List<SchoolList> GetSchoolList();
    }
}
