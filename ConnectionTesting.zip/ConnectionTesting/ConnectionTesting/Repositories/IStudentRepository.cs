﻿using ConnectionTesting.Models;

namespace ConnectionTesting.Repositories
{
    public interface IStudentRepository
    {
        List<StudentList> GetStudentLists(short pg_no);

        void UpdateStudent(StudentUpdate studentUpdate);
    }
}
