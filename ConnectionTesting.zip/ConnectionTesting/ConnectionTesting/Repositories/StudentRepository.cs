﻿using ConnectionTesting.Models;
using Microsoft.EntityFrameworkCore;
using System.IO;

namespace ConnectionTesting.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly PostgresContext mycontext;

        public StudentRepository(PostgresContext mycontext)
        {
            this.mycontext = mycontext;

        }


        public virtual List<StudentList> GetStudentLists(short pg_no)
        {
            try
            {
                if (pg_no <=0)
                {
                    return [];
                }
                else
                {
                    return mycontext.GetStudentLists(pg_no);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("catch entered");
                using StreamWriter writer = new StreamWriter("C:\\SagarBabu\\Error Log\\err.txt", true);
                writer.Write("--------------------------------------------------------------------------------------------------------------------------- \n" +
                                    DateTime.Now.ToString()
                                    + "\n" +
                                    ex.Message + ex.InnerException == null ? " " : ex.InnerException.ToString() +
                                    "\n------------------------------------------------------------------------------------------------------------------------\n");
                writer.Close();
                return new List<StudentList>();
            }

           // return [];
        }

        public void UpdateStudent(StudentUpdate studentUpdate)
        {
            string nameBlock, ageBlock, genderBlock;
   /*         StreamWriter writer = new StreamWriter("C:\\SagarBabu\\Error Log\\err.txt");*/

            if (studentUpdate.StudentName == string.Empty)
            {
                nameBlock = "St_Name => NULL";
            }
            else
            {
                nameBlock = $"St_Name => '{studentUpdate.StudentName}'";
            }

            if (studentUpdate.StudentAge == 0)
            {
                ageBlock = "St_Age=>NULL";
            }
            else
            {
                ageBlock = $"St_Age=>({studentUpdate.StudentAge}:: smallint)";

            }

            if (studentUpdate.StudentGender == string.Empty)
            {
                genderBlock = "St_Gender=>NULL";
            }
            else
            {
                genderBlock = $"St_Gender=>('{studentUpdate.StudentGender}'::character)";
            }

            //calling stored procedure for updating student details

            mycontext.Database.ExecuteSqlRaw($"call sp_put_student_details(St_Id=>({studentUpdate.StudentId} :: smallint)," + nameBlock + "," + ageBlock + "," + genderBlock + ")");

/*            writer.WriteLine("Testing of logging errors.");

            writer.Close();*/
            //mycontext.SaveChanges();
        }
    }
}
