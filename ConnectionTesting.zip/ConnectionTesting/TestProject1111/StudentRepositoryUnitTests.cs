using ConnectionTesting.Models;
using Moq;
using ConnectionTesting.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ConnectionTesting.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace TestProject1111
{
    public class StudentRepositoryUnitTests
    {
        [Theory]
        //[InlineData(0)]
        [InlineData(1)]
        public void GetStudentsListTest(short pageNo)
        {

            Mock<PostgresContext> postgresContext = new Mock<PostgresContext>();
            postgresContext.Setup(x => x.GetStudentLists(It.IsAny<short>())).Returns(new List<StudentList>() { new StudentList() });

            StudentRepository studentRepository = new StudentRepository(postgresContext.Object);

            List<StudentList> students = studentRepository.GetStudentLists(pageNo);

            Assert.Equal(students.Count(), 1);

        }

        [Theory]
        //[InlineData(0)]
        [InlineData(0)]
        public void GetStudentsListTest1(short pg_no)
        {
            Mock<PostgresContext> postgresContext = new Mock<PostgresContext>();

            Mock<StudentRepository> studentRepository = new Mock<StudentRepository>(postgresContext.Object);

            studentRepository.Setup(x => x.GetStudentLists(It.IsInRange<short>(1,20,Moq.Range.Inclusive))).Returns(new List<StudentList>() { new StudentList() });

            //StudentRepository strepo = new StudentRepository(postgresContext.Object);
            StudentController studentController = new StudentController(studentRepository.Object);

            IActionResult students = studentController.GetStudentListByPageNo(pg_no);
            
            OkObjectResult result = students as OkObjectResult;

            Assert.Equal(result.StatusCode,200);
        }

    }
}